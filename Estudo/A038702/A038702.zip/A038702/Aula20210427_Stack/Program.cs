﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20210427_Stack {
    class Program {
        static void Main(string[] args) {
            Lista vTemp = new Lista();
            vTemp.Add(1);
            vTemp.Add(1);
            vTemp.Add(1);
            vTemp.Add(1);
            Console.ReadKey();


        }
    }
}
